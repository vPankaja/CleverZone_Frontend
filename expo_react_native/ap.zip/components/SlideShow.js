import React from "react";
import { View, Image, StyleSheet, Dimensions } from "react-native";
import Swiper from "react-native-swiper";

const { width } = Dimensions.get("window");
const slideHeight = 300;
const slideWidth = width * 0.8;

const slides = [
  {
    image: require("./../assets/homecard.png"),
  },
  {
    image: require("./../assets/homecard.png"),
  },
  {
    image: require("./../assets/homecard.png"),
  },
];

const Slideshow = () => {
  return (
    <Swiper style={styles.wrapper} showsButtons={false} autoplay={true}>
      {slides.map((slide, index) => (
        <View key={index} style={styles.slide}>
          <Image source={slide.image} style={styles.image} />
        </View>
      ))}
    </Swiper>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    height: slideHeight,
  },
  slide: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    width: slideWidth,
    height: slideHeight,
  },
});

export default Slideshow;
