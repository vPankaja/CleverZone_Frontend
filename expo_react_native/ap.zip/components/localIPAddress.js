var LocalIP = "172.20.10.2";

export default LocalIP;
